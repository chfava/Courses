import java.awt.PageAttributes.ColorType;

/**
 * Classe PixelMapPlus
 * Image de type noir et blanc, tons de gris ou couleurs
 * Peut lire et ecrire des fichiers PNM
 * Implemente les methodes de ImageOperations
 * @author : 
 * @date   : 
 */

public class PixelMapPlus extends PixelMap implements ImageOperations 
{
	/**
	 * Constructeur creant l'image a partir d'un fichier
	 * @param fileName : Nom du fichier image
	 */
	PixelMapPlus(String fileName)
	{
		super( fileName );
	}
	
	/**
	 * Constructeur copie
	 * @param type : type de l'image a creer (BW/Gray/Color)
	 * @param image : source
	 */
	PixelMapPlus(PixelMap image)
	{
		super(image); 
	}
	
	/**
	 * Constructeur copie (sert a changer de format)
	 * @param type : type de l'image a creer (BW/Gray/Color)
	 * @param image : source
	 */
	PixelMapPlus(ImageType type, PixelMap image)
	{
		super(type, image); 
	}
	
	/**
	 * Constructeur servant a allouer la memoire de l'image
	 * @param type : type d'image (BW/Gray/Color)
	 * @param h : hauteur (height) de l'image 
	 * @param w : largeur (width) de l'image
	 */
	PixelMapPlus(ImageType type, int h, int w)
	{
		super(type, h, w);
	}
	
	/**
	 * Genere le negatif d'une image
	 */
	public void negate()
	{
		for (int i = 0; i < this.height; i++)
		{
			for (int j = 0; j < this.width; j++)
			{
				this.imageData[i][j] = this.imageData[i][j].Negative();
			}
		}
		
		
	}
	
	/**
	 * Convertit l'image vers une image en noir et blanc
	 */
	public void convertToBWImage()
	{
		for (int i = 0; i < this.height; i++){
			for (int j = 0; j < this.width; j++){
				this.imageData[i][j] = this.imageData[i][j].toBWPixel();
			}
		}
		
		
	}
	
	/**
	 * Convertit l'image vers un format de tons de gris
	 */
	public void convertToGrayImage()
	{
		for (int i = 0; i < this.height; i++)
		{
			for (int j = 0; j < this.width; j++)
			{
				this.imageData[i][j] = this.imageData[i][j].toGrayPixel();
			}
		}
		
	}
	
	/**
	 * Convertit l'image vers une image en couleurs
	 */
	public void convertToColorImage()
	{
		for (int i = 0; i < this.height; i++){
			for (int j = 0; j < this.width; j++){
				this.imageData[i][j] = this.imageData[i][j].toColorPixel();
			}
		}
		
	}
	
	public void convertToTransparentImage()
	{
		for (int i = 0; i < this.height; i++){
			for (int j = 0; j < this.width; j++){
				this.imageData[i][j] = this.imageData[i][j].toTransparentPixel();
			}
		}
		
	}
	
	/**
	 * Fait pivoter l'image de 10 degres autour du pixel (row,col)=(0, 0)
	 * dans le sens des aiguilles d'une montre (clockWise == true)
	 * ou dans le sens inverse des aiguilles d'une montre (clockWise == false).
	 * Les pixels vides sont blancs.
	 * @param clockWise : Direction de la rotation 
	 */
	public void rotate(int a, int b, double angleRadian)
	{	
		PixelMapPlus rotatedImage = new PixelMapPlus(this.imageType,this.height, this.width);
		
		for (int i = 0; i < this.height; i++){
			for (int j = 0; j < this.width; j++){
					switch(this.imageType){
						case BW :
							rotatedImage.imageData[i][j] = new BWPixel(false);
							break;
						case Gray :
							rotatedImage.imageData[i][j] = new GrayPixel(0);
							break;
						case Color :
							rotatedImage.imageData[i][j] = new ColorPixel();
							break;
						case Transparent :
							rotatedImage.imageData[i][j] = new TransparentPixel();
							break;
				}
			}
		}
		
		for (int i = 0; i < this.height; i++)
		{
			for (int j = 0; j < this.width; j++)
			{
				Double x = new Double(j * Math.cos(angleRadian) -  i * Math.sin(angleRadian) 
						- a * Math.cos(angleRadian) + b * Math.sin(angleRadian) + a);
				Double y = new Double(j * Math.sin(angleRadian) + i * Math.cos(angleRadian) 
				- a * Math.sin(angleRadian) - b * Math.cos(angleRadian) + b);
				int X = Math.abs(x.intValue());
				int Y = Math.abs(y.intValue());
				if (X >= 60){
					X = 59;
				};
				if (Y >= 60){
					Y = 59;
				};
				rotatedImage.imageData[Y][X] = this.imageData[i][j];
			}
		}
		this.imageData = rotatedImage.imageData;
		
		
	}
	
	/**
	 * Modifie la longueur et la largeur de l'image 
	 * @param w : nouvelle largeur
	 * @param h : nouvelle hauteur
	 */
	public void resize(int w, int h) throws IllegalArgumentException
	{
		
 		if(w < 0 || h < 0)
			throw new IllegalArgumentException();

 		PixelMapPlus ReImage = new PixelMapPlus(this.imageType,h,w) ;
 		float newWidth = w;
 		float newHeight = h;
 		float oldWidth = this.width;
 		float oldHeight = this.height;
		float relativeWidth= newWidth/oldWidth;
		float relativeHeight = newHeight/oldHeight;
		
		if (relativeWidth > 1 && relativeHeight > 1){
			for (float i = 0; i < this.height; i++){
				for (float j = 0; j < this.width; j++){
						int a = (int)(i*relativeHeight);
						int b = (int)(j*relativeWidth);
						ReImage.imageData[a][b] = this.imageData[(int)i][(int)j];
						for (int p = 0; p < (int)relativeHeight;p++){
							for (int q = 0; q < (int)relativeWidth;q++){
								ReImage.imageData[a+p][b+q] = ReImage.imageData[a][b];
							}
						}
						
					}
			}
		}
		
		else if (relativeWidth < 1 && relativeHeight < 1){
			float rapportLignes = this.width/ w;
			float rapportColonnes = this.height/h;
			for (int i = 0; i < ReImage.height; i++){
				for (int j = 0; j < ReImage.width; j++){
					ReImage.imageData[i][j] = this.imageData[(int)(i*rapportLignes)][(int)(j*rapportColonnes)];
				}
			}
		}
		this.imageData = ReImage.imageData; 
		this.height = ReImage.height;
		this.width = ReImage.width;
}
		
		
		

	/**
	 * Insert pm dans l'image a la position row0 col0
	 */
	public void inset(PixelMap pm, int row0, int col0)
	{
		for (int i = row0; i < this.height && i < pm.height + row0; i++){
			for (int j = col0; j < this.width && j < pm.width + col0; j++){
				this.imageData[i][j] = pm.imageData[i-row0][j-col0 ];
			}
		}	
	}
	
	/**
	 * Découpe l'image 
	 */
	public void crop(int h, int w)
	{
		PixelMap newImage = new PixelMap(this.imageType, h, w);
		for (int i = 0; i < h; i++){
			for (int j  = 0; j < w; j++){
				newImage.imageData[i][j] = this.imageData[i][j];
			}
		}
		
		this.imageData = newImage.imageData;	
		this.height = h;
		this.width = w;
		
	}
	
	/**
	 * Effectue une translation de l'image 
	 */
	public void translate(int rowOffset, int colOffset)
	{	
		for (int i = 0; i < this.height; i++)
		{
			for (int j = 0; i < this.width; j++)
			{
				this.imageData[i][j] = this.imageData[i + colOffset][j + rowOffset];
				
			}
		}
		for (int i = 0; i < Math.abs(colOffset); i++)
		{
			for (int j = 0; j < Math.abs(rowOffset); j++)
			{
		switch(this.imageType)
		{
		case BW :
			this.imageData[i][j] = new BWPixel(false);
			break;
		case Gray :
			this.imageData[i][j] = new GrayPixel(0);
			break;
		case Color :
			
			this.imageData[i][j] = new ColorPixel();
			break;
		case Transparent :
			this.imageData[i][j] = new TransparentPixel();
			break;
				}
	
			}
		}
}
	
	/**
	 * Effectue un zoom autour du pixel (x,y) d'un facteur zoomFactor 
	 * @param x : colonne autour de laquelle le zoom sera effectue
	 * @param y : rangee autour de laquelle le zoom sera effectue  
	 * @param zoomFactor : facteur du zoom a effectuer. Doit etre superieur a 1
	 */
	public void zoomIn(int x, int y, double zoomFactor) throws IllegalArgumentException
	{
		if(zoomFactor < 1.0)
			throw new IllegalArgumentException();
		
		
		Double zoom = new Double(zoomFactor);
		int zoomFact = zoom.intValue();
		int newWidth = this.getWidth()/zoomFact;
		int newHeight = this.getHeight()/zoomFact;
		
		PixelMapPlus newImage = new PixelMapPlus(this.imageType, newHeight, newWidth);
		int xStartPoint;
		if (x < newWidth)
		{
			xStartPoint = 0;
		}
		else
		{
			xStartPoint = x - (newWidth);
		}
		
		int yStartPoint;
		if (y < newHeight)
		{
			yStartPoint = 0;
		}
		else
		{
			yStartPoint = y - (newHeight);
		}
		
		for (int i = yStartPoint; i < ((yStartPoint + newHeight)); i++)
		{
			for(int j = xStartPoint; j < (xStartPoint + newWidth) ; j++)
			{
				newImage.imageData[i-yStartPoint][j-xStartPoint] = this.imageData[i][j];
			}
		}
		newImage.resize(this.width, this.height);
		
		this.imageData = newImage.imageData; 
		this.height = newImage.height;
		this.width = newImage.width;
		
		
	}
}

