from __future__ import print_function 
from flask import Flask
from flask import request
import boto3

  
app = Flask(__name__)
lambda_client = boto3.client('lambda', region_name='us-east-1')

@app.route('/sentiment', methods = ['POST'])
def postTweets():
    print("POST Method")
    tweets = request.get_json()

    ## Invoke serverless function 
    response = lambda_client.invoke(FunctionName="lambda_handler1", InvocationType='RequestResponse')
    print(response) 
    return str(response)

    pass

#################################
def convertCSVToJSON():
    import pandas as pd
    df = pd.read_csv ('/Users/charles-olivierfavreau/Downloads/input 3.csv', encoding = "latin")
    df.to_json ('/Users/charles-olivierfavreau/Downloads/input.json', orient = "index")

#################################

app.run(host='0.0.0.0', port= 5000)

